# İşletme Command Center — Android

Koyu/neon görünümlü, tamamen çevrimdışı çalışan görev takip dashboard'u.

## İçerik
- Kullanıcının verdiği 13 başlangıç görevi hazır gelir.
- Görev tamamla / geri aç.
- Tümü, aktif, yüksek öncelik ve tamamlanan filtreleri.
- Otomatik ilerleme yüzdesi ve durum kartları.
- Yeni görev ekleme.
- Veriler cihazdaki WebView LocalStorage içinde kalıcı saklanır.

## Android Studio ile APK
1. Bu klasörü Android Studio'da aç.
2. Gradle sync'in bitmesini bekle.
3. **Build > Build APK(s)** seç.
4. Çıktı: `app/build/outputs/apk/debug/app-debug.apk`

## GitHub ile otomatik APK
Projeyi bir GitHub reposuna yükle. `Actions > Build APK > Run workflow` seç.
Build bittikten sonra `command-center-apk` artifact'ını indir.

Not: Debug APK doğrudan Android cihazına kurulabilir. Play Store yayını için release signing gerekir.
